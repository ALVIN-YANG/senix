import hashlib,json,os,pty,re,secrets,select,shlex,signal,socket,stat,subprocess,tarfile,tempfile,termios,threading,time,urllib.request,urllib.error
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path

root=Path.cwd();work=root/'target/package-preflight';mini=work/'repack-root'
def deadline(*args):raise TimeoutError('guide validation exceeded 90 seconds')
signal.signal(signal.SIGALRM,deadline);signal.alarm(90)
archive=next((mini/'dist').glob('*aarch64-apple-darwin.tar.gz'))
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
servers=[];process=None;results=[]
def backend(label):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            body=label.encode();self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
        def log_message(self,*args):pass
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    threading.Thread(target=server.serve_forever,daemon=True).start();servers.append(server);return server.server_port
def port():
    with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def request(port,path,body=None,headers=None):
    req=urllib.request.Request(f'http://127.0.0.1:{port}{path}',data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json',**(headers or {})})
    try:response=opener.open(req,timeout=2)
    except urllib.error.HTTPError as error:response=error
    with response:return response.status,response.read().decode(),response.headers
def bootstrap(script,cwd,password):
    master,slave=pty.openpty();process=subprocess.Popen(['bash','-c',script],cwd=cwd,stdin=slave,stdout=slave,stderr=slave,start_new_session=True);os.close(slave)
    output=b'';sent=False;hidden=False;deadline=time.monotonic()+15
    try:
        while process.poll() is None:
            assert time.monotonic()<deadline,'guide bootstrap timed out'
            if select.select([master],[],[],.05)[0]:
                try:
                    data=os.read(master,65536)
                    if not data:break
                    output+=data
                except OSError:break
            if not sent and b'Owner password (12-256 characters): ' in output:
                hidden=not bool(termios.tcgetattr(master)[3]&termios.ECHO)
                assert hidden,'password prompt left terminal echo enabled'
                os.write(master,password.encode()+b'\n');sent=True
        process.wait(timeout=2)
        while select.select([master],[],[],0)[0]:
            try:
                data=os.read(master,65536)
                if not data:break
                output+=data
            except OSError:break
        assert sent and hidden and password.encode() not in output,'password was not read privately'
        assert termios.tcgetattr(master)[3]&termios.ECHO,'terminal echo was not restored'
        return output
    finally:
        if process.poll() is None:process.kill();process.wait()
        os.close(master)
def start(command,cwd,admin):
    global process
    process=subprocess.Popen(['bash','-c','exec '+command],cwd=cwd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    deadline=time.monotonic()+10
    while time.monotonic()<deadline:
        assert process.poll() is None,'documented startup exited'
        try:
            if request(admin,'/healthz')[0]==200:return
        except OSError:pass
        time.sleep(.05)
    raise AssertionError('documented startup did not become ready')
def stop():
    global process
    if process:
        process.send_signal(signal.SIGINT)
        try:process.wait(timeout=8)
        except subprocess.TimeoutExpired:process.kill();process.wait();raise
        process=None
try:
    a,b=backend('guide-A'),backend('guide-B')
    for recover in [False,True]:
        with tempfile.TemporaryDirectory(prefix='senix-archive-guide-') as directory:
            with tarfile.open(archive) as tar:tar.extractall(directory,filter='data')
            cwd=next(p for p in Path(directory).iterdir() if p.is_dir());readme=(cwd/'README.md').read_text();blocks=re.findall(r'```bash\n(.*?)\n```',readme,re.S);assert len(blocks)==4
            assert subprocess.check_output(['bash','-c',blocks[0]],cwd=cwd,text=True).strip()=='senixd 0.4.0'
            password=secrets.token_urlsafe(32)
            output=bootstrap(blocks[1],cwd,'short' if recover else password)
            match=re.search(rb'"api_key"\s*:\s*"([^"\s]+)"',output);assert match,'bootstrap key absent'
            key=match.group(1).decode()
            if recover:
                assert b'owner password must contain 12 to 256 characters' in output,'wrong password failure'
                retry='read -r'+blocks[1].split('read -r',1)[1]
                bootstrap(retry,cwd,password)
            assert stat.S_IMODE((cwd/'senix.db').stat().st_mode)==0o600
            config_path=cwd/'examples/gateway.json';config=json.loads(config_path.read_text())
            for entry,port_value in zip(config['routes'][0]['backends'],[a,b]):entry['address']=f'127.0.0.1:{port_value}'
            config_path.write_text(json.dumps(config));proxy,admin=port(),port()
            command=blocks[2].replace('127.0.0.1:8080',f'127.0.0.1:{proxy}').replace('127.0.0.1:9080',f'127.0.0.1:{admin}')
            start(command,cwd,admin)
            assert request(admin,'/api/v1/auth/login',{'username':'admin','password':password})[0]==200
            assert request(admin,'/api/v1/instances',headers={'Authorization':'Bearer '+key})[0]==401
            checks=blocks[3].replace('127.0.0.1:8080',f'127.0.0.1:{proxy}').replace('127.0.0.1:9080',f'127.0.0.1:{admin}')
            deadline=time.monotonic()+20
            while True:
                result=subprocess.run(['bash','-c',checks],cwd=cwd,capture_output=True,text=True,timeout=5)
                if result.returncode==0 and ('guide-A' in result.stdout or 'guide-B' in result.stdout):break
                assert time.monotonic()<deadline,'documented curl checks failed';time.sleep(.25)
            stop();config['routes'][0]['host']='ignored-startup.test';config_path.write_text(json.dumps(config));start(command,cwd,admin)
            assert request(admin,'/api/v1/auth/login',{'username':'admin','password':password})[0]==200
            deadline=time.monotonic()+20
            while request(proxy,'/',headers={'Host':'example.test'})[0]!=200:
                assert time.monotonic()<deadline;time.sleep(.25)
            assert request(proxy,'/',headers={'Host':'ignored-startup.test'})[0]==404
            stop()
            results.append({'password_recovery_case':recover,'documented_bash_blocks_executed':True,'password_echo_disabled_and_restored':True,'password_absent_from_terminal_output':True,'owner_login':200,'bootstrap_key_after_owner_creation':401,'database_mode':'0600','curl_health_and_real_proxy_passed':True,'restart_preserves_owner_and_saved_config':True})
    (work/'guide.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'cases':results,'temporary_fixtures_removed':True},indent=2)+'\n');print(json.dumps(results))
finally:
    signal.alarm(0)
    stop()
    for server in servers:server.shutdown();server.server_close()
