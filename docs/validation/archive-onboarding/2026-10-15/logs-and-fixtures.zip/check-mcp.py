import argparse,copy,hashlib,json,os,secrets,socket,subprocess,threading,time,urllib.request,urllib.error
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import tempfile
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--assets',type=Path,required=True);args=p.parse_args();binary=args.binary.resolve();args.output.mkdir(parents=True,exist_ok=False)
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
password=secrets.token_urlsafe(32);process=None;servers=[];evidence={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'checks':[]}
def require(condition,message):
 if not condition:raise RuntimeError(message)
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def backend(label):
 class Handler(BaseHTTPRequestHandler):
  def do_GET(self):
   data=label.encode();self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  def log_message(self,*unused):pass
 server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start();servers.append(server);return server.server_port
def cli(arguments,input=None):
 run=subprocess.run([str(binary),*arguments],input=input,text=True,capture_output=True,timeout=15)
 require(run.returncode==0,'packaged CLI command failed: '+arguments[0]);return run.stdout
try:
 evidence['version']=cli(['--version']).strip()
 a,b=backend('A'),backend('B');proxy,admin=port(),port()
 def request(path,body=None,headers=None,proxy_host=None):
  req=urllib.request.Request(f'http://127.0.0.1:{proxy if proxy_host else admin}{path}',data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json',**({'Host':proxy_host} if proxy_host else {}),**(headers or {})})
  try:response=opener.open(req,timeout=5)
  except urllib.error.HTTPError as error:response=error
  with response:
   raw=response.read().decode();return response.status,raw if proxy_host or path.startswith('/admin/') or path=='/healthz' else json.loads(raw),response.headers
 with tempfile.TemporaryDirectory(prefix='senix-package-check-') as d:
  db=Path(d)/'state.db';config=Path(d)/'config.json'
  candidate={'routes':[{'id':name,'host':host,'path_prefix':'/','backends':[{'id':'backend-'+name,'address':f'127.0.0.1:{upstream}','generation':1,'weight':100}]} for name,host,upstream in [('main','old.test',a),('untouched','untouched.test',b)]]}
  config.write_text(json.dumps(candidate));bootstrap=json.loads(cli(['credential','bootstrap','--db',str(db),'--label','package-owner']))
  cli(['owner','bootstrap','--db',str(db),'--username','admin','--password-stdin'],password)
  def start():
   global process
   process=subprocess.Popen([str(binary),'--listen',f'127.0.0.1:{proxy}','--admin-listen',f'127.0.0.1:{admin}','--db',str(db),'--config',str(config),'--shutdown-grace-seconds','1','--shutdown-timeout-seconds','1'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   deadline=time.monotonic()+15
   while time.monotonic()<deadline:
    require(process.poll() is None,'packaged server exited before readiness')
    try:
     if request('/healthz')[0]==200:return
    except (OSError,TimeoutError):pass
    time.sleep(.05)
   raise RuntimeError('packaged server did not become ready')
  def stop():
   global process
   if process is not None:
    process.terminate()
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:process.kill();process.wait()
    process=None
  start();require(request('/admin/')[0]==200,'embedded admin missing')
  evidence['embedded_assets_sha256']={}
  for filename,path in [('admin.html','/admin/'),('admin.js','/admin/admin.js'),('admin.css','/admin/admin.css')]:
   status,body,_=request(path);require(status==200,'embedded asset unavailable: '+filename)
   require(body.encode()==(args.assets/filename).read_bytes(),'embedded asset differs from source: '+filename)
   evidence['embedded_assets_sha256'][filename]=hashlib.sha256(body.encode()).hexdigest()

  status,_,headers=request('/api/v1/auth/login',{'username':'admin','password':password});require(status==200,'Owner login failed');owner={'Cookie':headers['Set-Cookie'].split(';')[0],'X-Senix-CSRF':'1'}
  status,key,_=request('/api/v1/credentials',{'label':'package-agent','actions':['change.read','change.plan','change.apply'],'all_resources':True,'instance_ids':[]},owner);require(status==201,'API Key issuance failed');bearer={'Authorization':'Bearer '+key['api_key']}
  def rpc(method,params):
   status,data,_=request('/mcp',{'jsonrpc':'2.0','id':1,'method':method,'params':params},{**bearer,'Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25','Mcp-Method':method});require(status==200 and 'error' not in data,'packaged MCP request failed');return data['result']
  def tool(name,arguments):return rpc('tools/call',{'name':name,'arguments':arguments})
  tools=rpc('tools/list',{})['tools'];plan_schema=next(t['inputSchema'] for t in tools if t['name']=='plan_change');require('expected_version' in plan_schema['required'],'read-version precondition absent');require(not any(t['name']=='approve_change' for t in tools),'MCP unexpectedly grants approval')
  read=tool('get_current_config',{})['structuredContent'];require(read['version']==1,'unexpected initial version');changed=copy.deepcopy(read['config']);changed['routes'][0]['host']='new.test'
  plan=tool('plan_change',{'expected_version':read['version'],'candidate':changed})['structuredContent'];require(not plan['issues'] and plan['base_version']==1,'invalid MCP plan');cid=plan['change_id']
  denied=tool('apply_approved_change',{'change_id':cid});require(denied['structuredContent']['code']=='CHANGE_APPROVAL_REQUIRED','unapproved apply was not rejected')
  require(request(f'/api/v1/changes/{cid}/approve',{},owner)[0]==200,'Owner approval failed')
  require(tool('get_change',{'change_id':cid})['structuredContent']['status']=='APPROVED','approved plan not visible')
  applied=tool('apply_approved_change',{'change_id':cid})['structuredContent'];require(applied['version']==2,'MCP apply failed');require(tool('apply_approved_change',{'change_id':cid})['structuredContent']==applied,'repeat apply changed version')
  for host,expected_status,expected_body in [('new.test',200,'A'),('untouched.test',200,'B'),('old.test',404,None)]:
   status,body,_=request('/',proxy_host=host);require(status==expected_status and (expected_body is None or body==expected_body),'real proxy check failed for '+host)
  stop();start();require(request('/api/v1/auth/login',{'username':'admin','password':password})[0]==200,'original Owner password lost on restart');current=tool('get_current_config',{})['structuredContent'];require(current['version']==2 and current['config']==changed,'exact config lost on restart')
  for host,expected in [('new.test','A'),('untouched.test','B')]:require(request('/',proxy_host=host)[:2]==(200,expected),'restarted proxy check failed')
  evidence['checks']=['packaged CLI and exact embedded HTML/JS/CSS','Owner bootstrap, login and scoped Key','MCP typed version precondition','read-plan-owner approval-apply','unapproved apply rejected','repeat apply idempotent','changed, unchanged and old host requests','restart preserves v2, exact config, Owner and Key']
  evidence['status']='passed';stop()
except Exception as error:
 evidence['status']='failed';evidence['error']=str(error);raise
finally:
 if process is not None:
  process.kill();process.wait()
 for server in servers:server.shutdown();server.server_close()
 (args.output/'result.json').write_text(json.dumps(evidence,indent=2)+'\n')
 print(json.dumps(evidence,indent=2))
