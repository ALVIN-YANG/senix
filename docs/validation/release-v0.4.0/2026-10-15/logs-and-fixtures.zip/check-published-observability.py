import json,os,secrets,subprocess,time,urllib.request,urllib.error,urllib.parse,uuid
from pathlib import Path
root=Path.cwd();out=root/'target/release-v040/observability';out.mkdir(parents=True,exist_ok=False)
password=secrets.token_urlsafe(32);key=None;follower=None;stream=None
project='senix-release-monitor-'+uuid.uuid4().hex[:8];monitor=project+'-collectors'
env={**os.environ,'COMPOSE_PROJECT_NAME':project,'SENIX_DEMO_PROXY_PORT':'18080','SENIX_DEMO_ADMIN_PORT':'19080','SENIX_IMAGE':'ghcr.io/alvin-yang/senix:0.4.0','SENIX_DEMO_PULL':'0','SENIX_DEMO_PASSWORD':password}
compose=['docker','compose','--project-directory',str(root/'examples/demo'),'-f',str(root/'examples/demo/compose.yml')]
collector=['docker','compose','-p',monitor,'-f',str(root/'examples/observability/compose.yml'),'--profile','collectors']
private=out/'private';private.mkdir(mode=0o700);token=private/'metrics-token';logs=out/'logs';logs.mkdir()
menv={**env,'SENIX_METRICS_KEY_FILE':str(token),'SENIX_DOCKER_NETWORK':project+'_senix-demo','SENIX_LOG_DIR':str(logs)}
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));result={'release_tag':'v0.4.0','status':'running'}
def redact(s):
 for secret in [password,key]:
  if secret:s=s.replace(secret,'<REDACTED>')
 return s.replace(str(root),'<REPO>')
def command(args,environment=env,timeout=120):
 r=subprocess.run(args,env=environment,text=True,capture_output=True,timeout=timeout)
 with (out/'commands.log').open('a') as f:f.write(redact(r.stdout+r.stderr)+'\n')
 assert r.returncode==0,'command failed: '+str(args[0:3])
 return r.stdout
def request(path,body=None,headers=None,method=None):
 req=urllib.request.Request('http://127.0.0.1:19080'+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json',**(headers or {})},method=method)
 with opener.open(req,timeout=5) as r:
  raw=r.read().decode();return r.status,json.loads(raw) if raw else None,r.headers
try:
 command(['./scripts/demo.sh'])
 override=out/'logging-override.json';override.write_text(json.dumps({'services':{'senix':{'command':['--listen','0.0.0.0:8080','--admin-listen','0.0.0.0:9080','--db','/var/lib/senix/senix.db','--config','/etc/senix/gateway.json','--log-format','json'],'environment':{'RUST_LOG':'senixd=info,senix_pingora::access=debug'}}}}))
 command([*compose,'-f',str(override),'up','-d','senix'])
 for _ in range(60):
  try:
   with opener.open('http://127.0.0.1:19080/healthz',timeout=1) as r:
    if r.status==200:break
  except OSError:pass
  time.sleep(.25)
 else:raise AssertionError('gateway failed to start with JSON logs')
 _,_,headers=request('/api/v1/auth/login',{'username':'admin','password':password});owner={'Cookie':headers['Set-Cookie'].split(';')[0],'X-Senix-CSRF':'1'}
 _,issued,_=request('/api/v1/credentials',{'label':'release-observability','actions':['metrics.read'],'instance_ids':[],'all_resources':True},owner);key=issued['api_key'];token.write_text(key);token.chmod(0o644)
 cid=command([*compose,'ps','-q','senix']).strip();stream=(logs/'senix.jsonl').open('w');follower=subprocess.Popen(['docker','logs','--follow',cid],stdout=stream,stderr=subprocess.DEVNULL)
 command(collector+['up','-d'],menv)
 check=subprocess.run(['python3','scripts/check-observability.py','--key-file',str(token),'--admin','http://127.0.0.1:19080','--proxy','http://127.0.0.1:18080','--collectors'],env=menv,text=True,capture_output=True,timeout=240)
 (out/'checks.log').write_text(redact(check.stdout+check.stderr));print(redact(check.stdout),flush=True);assert check.returncode==0,'observability acceptance failed'
 _,credentials,_=request('/api/v1/credentials',headers=owner)
 if isinstance(credentials,dict):credentials=credentials['credentials']
 credential=next(c for c in credentials if c['label']=='release-observability')
 def promq(expression):
  with opener.open('http://127.0.0.1:19090/api/v1/query?'+urllib.parse.urlencode({'query':expression}),timeout=5) as r:return json.load(r)['data']['result']
 diagnostic={'p95':promq('histogram_quantile(0.95, sum by (le) (rate(senix_proxy_request_duration_seconds_bucket{kind="ordinary"}[1m])))'),'counter_samples':promq('senix_proxy_request_duration_seconds_count{kind="ordinary"}[1m]')}
 (out/'promql-evidence.json').write_text(json.dumps(diagnostic,indent=2)+'\n')
 assert request('/api/v1/credentials/'+credential['credential_id'],headers=owner,method='DELETE')[0]==204
 query='http://127.0.0.1:19090/api/v1/query?'+urllib.parse.urlencode({'query':'up{job="senix"} == 0'})
 for _ in range(30):
  with opener.open(query,timeout=3) as r:data=json.load(r)
  if data['data']['result']:break
  time.sleep(1)
 else:raise AssertionError('revoked metrics Key still scraped')
 result.update(status='passed',image=json.loads(command(['docker','image','inspect',env['SENIX_IMAGE']]))[0]['RepoDigests'],checks=check.stdout.splitlines(),revoked_metrics_key_up_zero=True)
 print('PASS revoked metrics Key results in Prometheus up=0',flush=True)
except Exception as error:
 result.update(status='failed',error=str(error));raise
finally:
 subprocess.run(collector+['down','--volumes'],env=menv,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=120)
 if follower is not None:follower.terminate();follower.wait(timeout=15)
 if stream is not None:stream.close()
 subprocess.run([*compose,'down','--volumes'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=120)
 if token.exists():token.unlink()
 private.rmdir()
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
