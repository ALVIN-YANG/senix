import contextlib,hashlib,http.server,io,json,socket,subprocess,threading
from pathlib import Path
before=subprocess.check_output(['git','show','v0.4.0:scripts/check-observability.py'],text=True)
after=Path('scripts/check-observability.py').read_text()
results={}
for label,source in [('before',before),('after',after)]:
 attempts=[]
 class Handler(http.server.BaseHTTPRequestHandler):
  def do_GET(self):
   attempts.append(1)
   if len(attempts)==1:
    self.connection.shutdown(socket.SHUT_RDWR);self.connection.close();return
   self.send_response(200);self.end_headers();self.wfile.write(b'ready')
  def log_message(self,*args):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();namespace={'__name__':'observability_retry_fixture'};exec(compile(source,label,'exec'),namespace)
 try:
  with contextlib.redirect_stdout(io.StringIO()):response=namespace['eventually'](lambda:namespace['get']('http://127.0.0.1:'+str(server.server_port)+'/'),'cold HTTP retry',timeout=5)
  outcome={'status':'passed','response':response,'attempts':len(attempts)}
 except Exception as error:outcome={'status':'failed','exception':type(error).__name__,'attempts':len(attempts)}
 finally:server.shutdown();server.server_close();worker.join()
 results[label]={**outcome,'source_sha256':hashlib.sha256(source.encode()).hexdigest()}
assert results['before']['status']=='failed' and results['before']['exception']=='RemoteDisconnected'
assert results['after']['status']=='passed' and results['after']['response']=='ready' and results['after']['attempts']==2
Path('target/release-v040/cold-http-retry.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
