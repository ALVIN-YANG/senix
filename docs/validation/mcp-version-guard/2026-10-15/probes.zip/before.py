import copy,json,os,secrets,subprocess,time,urllib.request,urllib.error,uuid
from pathlib import Path
os.umask(0o077)
password=secrets.token_urlsafe(32)
env={**os.environ,'COMPOSE_PROJECT_NAME':'senix-plan-window-'+uuid.uuid4().hex[:10],
     'SENIX_DEMO_PROXY_PORT':'18080','SENIX_DEMO_ADMIN_PORT':'19080','SENIX_DEMO_HOST':'demo.senix.local',
     'SENIX_DEMO_PULL':'0','SENIX_IMAGE':'senix:english-docs','SENIX_DEMO_PASSWORD':password}
compose=['docker','compose','--project-directory','examples/demo','--file','examples/demo/compose.yml']
def request(path,body=None,headers=None,proxy=False):
 req=urllib.request.Request(('http://127.0.0.1:18080' if proxy else 'http://127.0.0.1:19080')+path,
   data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json',**(headers or {})})
 try: response=urllib.request.urlopen(req,timeout=10)
 except urllib.error.HTTPError as error: response=error
 with response:
  raw=response.read().decode()
  return response.status,raw if proxy else json.loads(raw),response.headers
try:
 startup=subprocess.run(['./scripts/demo.sh'],env=env,text=True,capture_output=True,timeout=120)
 assert startup.returncode==0,'isolated demo startup failed'
 status,_,headers=request('/api/v1/auth/login',{'username':'admin','password':password})
 assert status==200
 owner={'Cookie':headers['Set-Cookie'].split(';')[0],'X-Senix-CSRF':'1'}
 status,issued,_=request('/api/v1/credentials',{'label':'read-plan-window-probe','actions':['change.read','change.plan'],'all_resources':True,'instance_ids':[],'expires_at_ms':int(time.time()*1000)+3600000},owner)
 assert status==201
 def mcp(method,params):
  status,data,_=request('/mcp',{'jsonrpc':'2.0','id':1,'method':method,'params':params},
    {'Authorization':'Bearer '+issued['api_key'],'Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25','Mcp-Method':method})
  assert status==200 and 'error' not in data
  return data['result']
 def tool(name,arguments): return mcp('tools/call',{'name':name,'arguments':arguments})
 read=tool('get_current_config',{})['structuredContent']
 assert read['version']==1
 stale_candidate=copy.deepcopy(read['config'])
 stale_candidate['routes'][0]['host']='ai-change.senix.local'
 owner_candidate=copy.deepcopy(read['config'])
 added=copy.deepcopy(owner_candidate['routes'][0])
 added['id']='owner-added-route'
 added['host']='owner-added.senix.local'
 for backend in added['backends']: backend['id']='owner-'+backend['id']
 owner_candidate['routes'].append(added)
 status,plan,_=request('/api/v1/changes/plan',owner_candidate,owner)
 assert status==201 and not plan['issues']
 path='/api/v1/changes/'+plan['change_id']
 assert request(path+'/approve',{},owner)[0]==200
 status,applied,_=request(path+'/apply',{},owner)
 assert status==200 and applied['version']==2
 for _ in range(40):
  owner_status=request('/',headers={'Host':'owner-added.senix.local'},proxy=True)[0]
  if owner_status==200:break
  time.sleep(.1)
 assert owner_status==200
 accepted=tool('plan_change',{'candidate':stale_candidate})
 assert not accepted.get('isError')
 stale_plan=accepted['structuredContent']
 assert stale_plan['base_version']==2 and not stale_plan['issues']
 assert stale_plan['diff']['removed_routes']==['owner-added-route']
 current=tool('get_current_config',{})['structuredContent']
 assert current['version']==2 and current['config']==owner_candidate
 tools=mcp('tools/list',{})['tools']
 schema=next(t['inputSchema'] for t in tools if t['name']=='plan_change')
 result={'source_baseline':'af40d95','ai_read_version':read['version'],'owner_published_version':applied['version'],
         'owner_added_route_status':owner_status,'stale_candidate_was_accepted_for_planning':True,
         'accepted_plan_base_version':stale_plan['base_version'],'candidate_removed_routes':stale_plan['diff']['removed_routes'],
         'plan_was_not_approved_or_applied':True,'live_configuration_still_matches_owner_v2':True,
         'candidate_input_schema':schema['properties']['candidate'],'required_tool_parameters':schema.get('required',[])}
 Path('target/read-plan-window-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
finally:
 subprocess.run([*compose,'down','--volumes'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
