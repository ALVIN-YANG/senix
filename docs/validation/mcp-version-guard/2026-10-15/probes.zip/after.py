import copy,json,os,secrets,subprocess,time,urllib.request,urllib.error,uuid
from pathlib import Path
os.umask(0o077)
output=Path(os.environ.get('SENIX_PROBE_OUTPUT','target/mcp-version-guard-probe'));output.mkdir(parents=True,exist_ok=False)
password=secrets.token_urlsafe(32)
env={**os.environ,'COMPOSE_PROJECT_NAME':'senix-version-guard-'+uuid.uuid4().hex[:10],
     'SENIX_DEMO_PROXY_PORT':'18080','SENIX_DEMO_ADMIN_PORT':'19080','SENIX_DEMO_HOST':'demo.senix.local',
     'SENIX_DEMO_PULL':'0','SENIX_IMAGE':'senix:version-guard','SENIX_DEMO_PASSWORD':password}
compose=['docker','compose','--project-directory','examples/demo','--file','examples/demo/compose.yml']
def request(path,body=None,headers=None,proxy=False):
 req=urllib.request.Request(('http://127.0.0.1:18080' if proxy else 'http://127.0.0.1:19080')+path,
   data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json',**(headers or {})})
 try: response=urllib.request.urlopen(req,timeout=10)
 except urllib.error.HTTPError as error: response=error
 with response:
  raw=response.read().decode()
  return response.status,raw if proxy else json.loads(raw),response.headers
try:
 startup=subprocess.run(['./scripts/demo.sh'],env=env,text=True,capture_output=True,timeout=120)
 (output/'startup.txt').write_text((startup.stdout+startup.stderr).replace(password,'[REDACTED]'))
 if startup.returncode != 0:
  diagnostics=subprocess.run([*compose,'logs','--no-color'],env=env,text=True,capture_output=True,timeout=30)
  (output/'startup-diagnostics.txt').write_text((diagnostics.stdout+diagnostics.stderr).replace(password,'[REDACTED]'))
 assert startup.returncode==0,'isolated demo startup failed; inspect sanitized startup evidence'
 status,_,headers=request('/api/v1/auth/login',{'username':'admin','password':password})
 assert status==200
 owner={'Cookie':headers['Set-Cookie'].split(';')[0],'X-Senix-CSRF':'1'}
 status,issued,_=request('/api/v1/credentials',{'label':'read-plan-window-probe','actions':['change.read','change.plan','change.apply'],'all_resources':True,'instance_ids':[],'expires_at_ms':int(time.time()*1000)+3600000},owner)
 assert status==201
 def mcp(method,params):
  status,data,_=request('/mcp',{'jsonrpc':'2.0','id':1,'method':method,'params':params},
    {'Authorization':'Bearer '+issued['api_key'],'Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25','Mcp-Method':method})
  assert status==200 and 'error' not in data
  return data['result']
 def tool(name,arguments): return mcp('tools/call',{'name':name,'arguments':arguments})
 read=tool('get_current_config',{})['structuredContent']
 assert read['version']==1
 stale_candidate=copy.deepcopy(read['config'])
 stale_candidate['routes'][0]['host']='ai-change.senix.local'
 owner_candidate=copy.deepcopy(read['config'])
 added=copy.deepcopy(owner_candidate['routes'][0])
 added['id']='owner-added-route'
 added['host']='owner-added.senix.local'
 for backend in added['backends']: backend['id']='owner-'+backend['id']
 owner_candidate['routes'].append(added)
 status,plan,_=request('/api/v1/changes/plan',owner_candidate,owner)
 assert status==201 and not plan['issues']
 path='/api/v1/changes/'+plan['change_id']
 assert request(path+'/approve',{},owner)[0]==200
 status,applied,_=request(path+'/apply',{},owner)
 assert status==200 and applied['version']==2
 for _ in range(40):
  owner_status=request('/',headers={'Host':'owner-added.senix.local'},proxy=True)[0]
  if owner_status==200:break
  time.sleep(.1)
 assert owner_status==200
 before=tool('list_changes',{})
 rejected=tool('plan_change',{'expected_version':read['version'],'candidate':stale_candidate})
 assert rejected.get('isError') is True
 error=rejected['structuredContent']
 assert error['code']=='CONFIG_VERSION_MISMATCH'
 assert error['evidence']=={'expected_version':1,'current_version':2}
 assert tool('list_changes',{})==before
 current=tool('get_current_config',{})['structuredContent']
 assert current['version']==2 and current['config']==owner_candidate
 merged=copy.deepcopy(current['config'])
 merged['routes'][0]['host']='ai-change.senix.local'
 planned=tool('plan_change',{'expected_version':current['version'],'candidate':merged})['structuredContent']
 assert planned['base_version']==2 and not planned['issues'] and planned['diff']['removed_routes']==[]
 assert tool('apply_approved_change',{'change_id':planned['change_id']})['structuredContent']['code']=='CHANGE_APPROVAL_REQUIRED'
 assert request('/api/v1/changes/'+planned['change_id']+'/approve',{},owner)[0]==200
 applied=tool('apply_approved_change',{'change_id':planned['change_id']})['structuredContent']
 assert applied['version']==3
 assert tool('apply_approved_change',{'change_id':planned['change_id']})['structuredContent']==applied
 final=tool('get_current_config',{})['structuredContent']
 assert final['version']==3 and final['config']==merged and final['config']['routes'][1]==added
 statuses={}
 for host,expected_status in [('ai-change.senix.local',200),('owner-added.senix.local',200),('demo.senix.local',404)]:
  statuses[host]=request('/',headers={'Host':host},proxy=True)[0]
  assert statuses[host]==expected_status
 schema=next(t['inputSchema'] for t in mcp('tools/list',{})['tools'] if t['name']=='plan_change')
 assert set(schema['required'])=={'expected_version','candidate'}
 missing=mcp('tools/call',{'name':'plan_change','arguments':{'candidate':merged}})
 assert missing.get('isError') is True and 'expected_version' in missing['content'][0]['text']
 result={'source_parent':'08b1816','source_changes':'MCP expected_version and GatewayConfig JSON Schema',
  'image':subprocess.check_output(['docker','image','inspect','--format','{{.Id}}',env['SENIX_IMAGE']],text=True).strip(),
  'ai_read_version':read['version'],'owner_published_version':current['version'],
  'owner_added_route_status':owner_status,'stale_candidate_rejected':True,
  'error':error,'no_plan_created_on_mismatch':True,'reread_merged_plan_base_version':planned['base_version'],
  'unapproved_apply_rejected':True,'owner_approved_change_id':planned['change_id'],'mcp_applied_version':final['version'],
  'repeated_apply_returned_original_version':True,'owner_added_route_preserved':True,'proxy_statuses':statuses,
  'missing_expected_version_rejected':True,'required_tool_parameters':schema['required']}
 (output/'after.json').write_text(json.dumps(result,indent=2)+'\n')
 (output/'schema.json').write_text(json.dumps(schema,indent=2)+'\n')
 print(json.dumps(result,indent=2))

finally:
 subprocess.run([*compose,'down','--volumes'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
