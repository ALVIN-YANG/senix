import argparse,datetime,json,os,re,secrets,subprocess,time,urllib.request,urllib.error,uuid
from pathlib import Path
ROOT=Path.cwd()
parser=argparse.ArgumentParser()
parser.add_argument('--runs',type=int,default=10)
parser.add_argument('--image',default='senix:version-guard')
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=False)
compose=['docker','compose','--project-directory',str(ROOT/'examples/demo'),'--file',str(ROOT/'examples/demo/compose.yml')]
results=[]
for index in range(1,args.runs+1):
 password=secrets.token_urlsafe(32)
 env={**os.environ,'COMPOSE_PROJECT_NAME':'senix-startup-diag-'+uuid.uuid4().hex[:10],
 'SENIX_DEMO_PROXY_PORT':'18080','SENIX_DEMO_ADMIN_PORT':'19080','SENIX_DEMO_HOST':'demo.senix.local',
 'SENIX_DEMO_PULL':'0','SENIX_IMAGE':args.image,'SENIX_DEMO_PASSWORD':password}
 out=args.output/f'run-{index}';out.mkdir()
 def redact(s):
  s=s.replace(password,'<REDACTED>').replace(str(ROOT),'<REPO>')
  return re.sub(r'\bsnxs?_[A-Za-z0-9_-]+','<REDACTED>',s)
 def command(argv,filename,timeout=120):
  try:
   done=subprocess.run(argv,env=env,cwd=ROOT,text=True,capture_output=True,timeout=timeout)
   raw=done.stdout+done.stderr;code=done.returncode
  except subprocess.TimeoutExpired as error:
   raw=''.join(v.decode(errors='replace') if isinstance(v,bytes) else v or '' for v in (error.stdout,error.stderr));code='timeout'
  (out/filename).write_text(redact(raw))
  return code
 result={'run':index,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'project':env['COMPOSE_PROJECT_NAME'],'image':args.image}
 start=time.monotonic()
 try:
  code=command(['./scripts/demo.sh'],'startup.txt');result['startup_exit']=code
  if code!=0:raise RuntimeError('demo startup did not exit zero')
  req=urllib.request.Request('http://127.0.0.1:18080/',headers={'Host':'demo.senix.local'})
  with urllib.request.urlopen(req,timeout=5) as response:
   result['proxy_status']=response.status
   if response.status!=200 or 'Hostname: backend-' not in response.read().decode():raise RuntimeError('real proxy check failed')
  req=urllib.request.Request('http://127.0.0.1:19080/api/v1/auth/login',data=json.dumps({'username':'admin','password':password}).encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=5) as response:
   result['owner_login_status']=response.status
   if response.status!=200:raise RuntimeError('original Owner login failed')
  result['status']='passed'
 except Exception as error:
  result['status']='failed';result['error']=redact(str(error))
  command([*compose,'ps','--all','--format','json'],'containers.json',20)
  command([*compose,'logs','--no-color','--tail','60'],'containers.txt',20)
 finally:
  result['elapsed_before_cleanup_seconds']=round(time.monotonic()-start,3)
  result['cleanup_exit']=command([*compose,'down','--volumes','--timeout','1'],'cleanup.txt',60)
  if result['cleanup_exit']!=0:result['status']='failed'
  results.append(result);(args.output/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps(result),flush=True)
 if result['status']!='passed':raise SystemExit(1)
