import json,os,re,secrets,subprocess,urllib.request,urllib.error,uuid
from pathlib import Path
root=Path.cwd();out=Path('target/demo-owner-recovery-before');out.mkdir(exist_ok=False)
password=secrets.token_urlsafe(32)
env={**os.environ,'COMPOSE_PROJECT_NAME':'senix-owner-recovery-'+uuid.uuid4().hex[:10],
'SENIX_DEMO_PROXY_PORT':'18080','SENIX_DEMO_ADMIN_PORT':'19080','SENIX_DEMO_HOST':'demo.senix.local',
'SENIX_DEMO_PULL':'0','SENIX_IMAGE':'senix:version-guard'}
compose=['docker','compose','--project-directory','examples/demo','--file','examples/demo/compose.yml']
def redact(text):return re.sub(r'\bsnxs?_[A-Za-z0-9_-]+','<REDACTED>',text.replace(password,'<REDACTED>').replace(str(root),'<REPO>'))
try:
 env['SENIX_DEMO_PASSWORD']='short'
 initial=subprocess.run(['./scripts/demo.sh'],env=env,text=True,capture_output=True,timeout=120)
 (out/'invalid-password.txt').write_text(redact(initial.stdout+initial.stderr))
 assert initial.returncode!=0
 env['SENIX_DEMO_PASSWORD']=password
 retry=subprocess.run(['./scripts/demo.sh'],env=env,text=True,capture_output=True,timeout=120)
 (out/'corrected-password.txt').write_text(redact(retry.stdout+retry.stderr))
 req=urllib.request.Request('http://127.0.0.1:19080/api/v1/auth/login',data=json.dumps({'username':'admin','password':password}).encode(),headers={'Content-Type':'application/json'})
 try:response=urllib.request.urlopen(req,timeout=5)
 except urllib.error.HTTPError as error:response=error
 with response:
  status=response.status;body=json.loads(response.read())
 result={'initial_demo_exit':initial.returncode,'retry_demo_exit':retry.returncode,'retry_reports_ready':'Senix demo is ready.' in retry.stdout,'owner_login_status':status,'owner_error':body.get('code'),'recovery_passed':retry.returncode==0 and status==200}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
 if not result['recovery_passed']:raise SystemExit(1)
finally:
 cleanup=subprocess.run([*compose,'down','--volumes','--timeout','1'],env=env,text=True,capture_output=True,timeout=60)
 (out/'cleanup.txt').write_text(redact(cleanup.stdout+cleanup.stderr))
