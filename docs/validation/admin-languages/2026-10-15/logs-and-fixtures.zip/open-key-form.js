async (page) => {
  await page.getByRole('button', {name: /^Access Keys/}).click();
  await page.getByRole('button', {name: 'Generate Key', exact: true}).click();
}
