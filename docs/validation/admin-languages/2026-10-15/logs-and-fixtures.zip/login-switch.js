async (page) => {
  await page.getByRole('textbox', {name: 'Username', exact: true}).fill('admin');
  await page.getByRole('textbox', {name: 'Password', exact: true}).fill('not-a-real-password');
  await page.getByRole('combobox', {name: 'Language'}).selectOption('zh-CN');
  if (await page.getByRole('textbox', {name: '用户名', exact: true}).inputValue() !== 'admin') throw new Error('Username lost during language switch');
  if (await page.getByRole('textbox', {name: '密码', exact: true}).inputValue() !== 'not-a-real-password') throw new Error('Password lost during language switch');
  await page.getByRole('button', {name: '进入控制台', exact: true}).click();
  await page.getByRole('alert').filter({hasText: '用户名或密码不正确。'}).waitFor();
  await page.getByRole('combobox', {name: '语言'}).selectOption('en');
  await page.getByRole('alert').filter({hasText: 'Incorrect username or password.'}).waitFor();
  if (await page.evaluate(() => document.documentElement.lang) !== 'en') throw new Error('Document language is stale');
  console.log('PASS login inputs and existing validation message survive language switches');
}
