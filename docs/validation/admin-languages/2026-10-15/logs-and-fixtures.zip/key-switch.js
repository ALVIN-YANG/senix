async (page) => {
  await page.getByRole('textbox', {name: 'Name', exact: true}).fill('locale-草稿');
  await page.getByRole('combobox', {name: 'Purpose', exact: true}).selectOption('apply');
  await page.getByRole('combobox', {name: 'Validity', exact: true}).selectOption('24');
  const requests = [];
  const record = request => { if (new URL(request.url()).pathname.startsWith('/api/')) requests.push(request.method() + ' ' + new URL(request.url()).pathname); };
  page.on('request', record);
  await page.getByRole('combobox', {name: 'Language', exact: true}).selectOption('zh-CN');
  await page.waitForLoadState('networkidle');
  if (await page.getByRole('textbox', {name: '名称', exact: true}).inputValue() !== 'locale-草稿') throw new Error('Key label lost');
  if (await page.getByRole('combobox', {name: '有效期', exact: true}).inputValue() !== '24') throw new Error('Key expiry changed');
  if (await page.getByRole('combobox', {name: '选择用途', exact: true}).inputValue() !== 'apply') throw new Error('Preset changed');
  if (await page.locator('input[name="actions"]:checked').count() !== 5) throw new Error('Preset grants changed');
  if (!await page.getByRole('checkbox', {name: '所有当前和未来实例', exact: true}).isChecked()) throw new Error('Global scope changed');
  await page.getByRole('combobox', {name: '语言', exact: true}).selectOption('en');
  await page.waitForLoadState('networkidle');
  page.off('request', record);
  return {formPreserved: true, grantsPreserved: true, requestsDuringSwitch: requests};
}
