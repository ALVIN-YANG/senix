async (page) => {
  const editor = page.getByRole('textbox', {name: 'Complete candidate configuration JSON', exact: true});
  const original = await editor.inputValue();
  const draft = '{ invalid-json: "不要丢弃"';
  await editor.fill(draft);
  await page.getByRole('button', {name: 'Create change plan', exact: true}).click();
  await page.getByRole('alert').filter({hasText: 'Invalid JSON. Correct it before creating a plan.'}).waitFor();
  const requests = [];
  const record = request => { if (new URL(request.url()).pathname.startsWith('/api/')) requests.push(request.method()); };
  page.on('request', record);
  await page.getByRole('combobox', {name: 'Language', exact: true}).selectOption('zh-CN');
  await page.getByRole('alert').filter({hasText: 'JSON 格式不正确，先修正后再规划。'}).waitFor();
  if (await page.getByRole('textbox', {name: '完整候选配置 JSON', exact: true}).inputValue() !== draft) throw new Error('Draft lost');
  await page.getByRole('combobox', {name: '语言', exact: true}).selectOption('en');
  await page.getByRole('alert').filter({hasText: 'Invalid JSON. Correct it before creating a plan.'}).waitFor();
  await page.waitForLoadState('networkidle');
  page.off('request', record);
  if (requests.length) throw new Error('Language switch caused API requests');
  await editor.fill(original);
  return {draftPreserved: true, existingErrorRetranslated: true, requestsDuringSwitch: requests};
}
