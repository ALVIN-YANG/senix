import json,re,subprocess,sys
from pathlib import Path
root=Path.cwd();private=root/'target/admin-i18n/runtime/private.json';state=json.loads(private.read_text());args=sys.argv[1:];mode=args[0]
if mode=='fill-password':args=['fill',args[1],state['password']]
if mode=='open':args=['open','http://127.0.0.1:'+str(state['admin'])+'/admin/','--headed','--config',str(root/'target/admin-i18n/browser.json')]
if mode=='capture-key':args=['--raw','eval',"document.querySelector('.secret-value').textContent"]
command=['<PLAYWRIGHT_CLI_WRAPPER>','--session','senix-locale',*args]
r=subprocess.run(command,cwd=root/'output/playwright/senix-locale',text=True,capture_output=True,timeout=120)
output=r.stdout+r.stderr
if mode=='snapshot':
 match=re.search(r'\[Snapshot\]\(([^)]+)\)',output)
 if match:output+='\n'+(root/'output/playwright/senix-locale'/match.group(1)).read_text()
if mode=='capture-key':
 match=re.search(r'\bsnxs?_[A-Za-z0-9_-]+',output);assert match,'UI did not expose a Key';state['api_key']=match.group();private.write_text(json.dumps(state));print('Captured the one-time UI-issued Key into the private fixture; no Key printed.')
else:
 for value in [state['password'],state.get('api_key')]:
  if value:output=output.replace(value,'<REDACTED>')
 output=re.sub(r'\bsnxs?_[A-Za-z0-9_-]+','<REDACTED>',output)
 with (root/'target/admin-i18n/browser-actions.log').open('a') as log:log.write('COMMAND '+mode+'\n'+output+'\n')
 print(output)
assert r.returncode==0 and '### Error' not in output,'Playwright CLI command failed'
