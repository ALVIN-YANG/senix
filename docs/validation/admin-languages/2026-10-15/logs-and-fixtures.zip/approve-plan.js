async (page) => {
  await page.getByText('View complete candidate configuration', {exact: true}).click();
  const candidate = JSON.parse(await page.locator('.change-card details pre').innerText());
  if (candidate.routes[0].host !== 'new.test' || candidate.routes[1].host !== 'untouched.test') throw new Error('Unexpected candidate shown to Owner');
  await page.getByRole('button', {name: 'Approve this exact content', exact: true}).click();
  await page.getByRole('button', {name: 'Apply approved plan', exact: true}).waitFor();
  return {ownerReviewedDisplayedCandidate: true, ownerApprovedInEnglishUI: true};
}
