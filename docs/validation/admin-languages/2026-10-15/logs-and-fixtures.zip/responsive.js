async (page) => {
  const pages = {
    en: ['Traffic status', 'Configuration changes', 'Request diagnostics', 'Access Keys', 'TLS certificates', 'Audit events'],
    'zh-CN': ['流量状态', '配置变更', '请求诊断', '访问 Key', 'TLS 证书', '审计记录']
  };
  const results = [];
  for (const locale of ['en', 'zh-CN']) {
    await page.getByRole('combobox', {name: /^(Language|语言)$/}).selectOption(locale);
    for (const width of [1360, 900, 620, 360, 320]) {
      await page.setViewportSize({width, height: 960});
      for (let index = 0; index < 6; index++) {
        await page.getByRole('navigation').getByRole('button').nth(index).click();
        await page.getByRole('heading', {level: 1, name: pages[locale][index], exact: true}).waitFor();
        if (await page.getByRole('navigation').getByRole('button').nth(index).getAttribute('aria-label') !== pages[locale][index]) throw new Error('Localized navigation name missing');
        const dimensions = await page.evaluate(() => ({viewport: window.innerWidth, scroll: document.documentElement.scrollWidth}));
        results.push({locale, width, accessibleNavigation: true, page: pages[locale][index], ...dimensions});
      }
    }
  }
  await page.setViewportSize({width: 1360, height: 960});
  await page.getByRole('combobox', {name: '语言', exact: true}).selectOption('en');
  await page.getByRole('navigation').getByRole('button').nth(1).click();
  await page.screenshot({path: 'english-changes-desktop.png', fullPage: true});
  await page.setViewportSize({width: 360, height: 960});
  await page.screenshot({path: 'english-changes-mobile.png', fullPage: true});
  await page.setViewportSize({width: 900, height: 960});
  const mediumNavigation = await page.getByRole('navigation').ariaSnapshot();
  await page.setViewportSize({width: 1360, height: 960});
  return {results, overflowing: results.filter(r => r.scroll > r.viewport), mediumNavigation};
}
