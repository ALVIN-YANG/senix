async (page) => {
  const browser = page.context().browser();
  const results = [];
  for (const scenario of ['chinese-browser', 'invalid-saved-language', 'blocked-storage']) {
    const context = await browser.newContext({locale: scenario === 'invalid-saved-language' ? 'en-US' : 'zh-CN'});
    try {
      if (scenario === 'invalid-saved-language') await context.addInitScript(() => localStorage.setItem('senix.language', 'invalid'));
      if (scenario === 'blocked-storage') await context.addInitScript(() => Object.defineProperty(window, 'localStorage', {get() {throw new DOMException('Storage disabled for test', 'SecurityError');}}));
      const probe = await context.newPage();
      await probe.goto(page.url());
      const expected = scenario === 'invalid-saved-language' ? 'Username' : '用户名';
      await probe.getByRole('textbox', {name: expected, exact: true}).waitFor();
      if (scenario === 'blocked-storage') {
        await probe.getByRole('combobox', {name: '语言', exact: true}).selectOption('en');
        await probe.getByRole('textbox', {name: 'Username', exact: true}).waitFor();
      }
      results.push({scenario, passed: true, documentLanguage: await probe.evaluate(() => document.documentElement.lang)});
    } finally { await context.close(); }
  }
  return {preferenceCases: results};
}
