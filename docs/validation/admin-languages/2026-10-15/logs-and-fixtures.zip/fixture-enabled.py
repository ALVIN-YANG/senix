import json,os,secrets,socket,subprocess,threading,time,urllib.request,urllib.error,signal
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
root=Path.cwd();folder=root/'target/admin-i18n/runtime';folder.mkdir(mode=0o700,exist_ok=False);os.umask(0o077);password=secrets.token_urlsafe(24);servers=[];process=None

def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def backend(label):
 class Handler(BaseHTTPRequestHandler):
  def do_GET(self):
   body=label.encode();self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
  def log_message(self,*args):pass
 server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start();servers.append(server);return server.server_port
binary=root/'target/debug/senixd';db=folder/'state.db';config=folder/'config.json';admin,proxy=port(),port();a,b=backend('locale-A'),backend('locale-B')
candidate={'routes':[{'id':id,'host':host,'path_prefix':'/','backends':[{'id':'backend-'+id,'address':'127.0.0.1:'+str(upstream),'generation':1,'weight':100}]} for id,host,upstream in [('main','old.test',a),('untouched','untouched.test',b)]]};config.write_text(json.dumps(candidate))
for arguments,input in [(['credential','bootstrap','--db',str(db),'--label','locale-owner'],None),(['owner','bootstrap','--db',str(db),'--username','admin','--password-stdin'],password)]:
 r=subprocess.run([str(binary),*arguments],input=input,text=True,capture_output=True,timeout=15);assert r.returncode==0
r=subprocess.run([str(binary),'secret-key','generate','--output',str(folder/'vault.key')],text=True,capture_output=True,timeout=15);assert r.returncode==0
state={'admin':admin,'proxy':proxy,'password':password,'binary':str(binary),'db':str(db),'config':str(config),'vault_key':str(folder/'vault.key'),'fixture_pid':os.getpid()};(folder/'private.json').write_text(json.dumps(state))
log=(folder/'server.log').open('w')
def stop(*args):
 if process is not None:
  process.terminate()
  try:process.wait(timeout=5)
  except subprocess.TimeoutExpired:process.kill();process.wait()
 for server in servers:server.shutdown();server.server_close()
 log.close();raise SystemExit(0)
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
process=subprocess.Popen([str(binary),'--listen','127.0.0.1:'+str(proxy),'--admin-listen','127.0.0.1:'+str(admin),'--db',str(db),'--config',str(config),'--secret-key-file',str(folder/'vault.key'),'--shutdown-grace-seconds','1','--shutdown-timeout-seconds','1'],stdout=log,stderr=log)
for _ in range(100):
 assert process.poll() is None
 try:
  with urllib.request.urlopen('http://127.0.0.1:'+str(admin)+'/healthz',timeout=1) as r:
   if r.status==200:break
 except OSError:pass
 time.sleep(.05)
else:raise RuntimeError('fixture not ready')
print(json.dumps({'status':'ready','admin_url':'http://127.0.0.1:'+str(admin)+'/admin/','proxy_port':proxy}),flush=True)
while True:time.sleep(30)
