import copy,hashlib,json,sys,time,urllib.request,urllib.error
from pathlib import Path
root=Path.cwd();folder=root/'target/admin-i18n/runtime';private=folder/'private.json';state=json.loads(private.read_text());opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));mode=sys.argv[1]
def request(path,body=None,headers=None,host=None):
 req=urllib.request.Request('http://127.0.0.1:'+str(state['proxy'] if host else state['admin'])+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json',**({'Host':host} if host else {}),**(headers or {})})
 try:r=opener.open(req,timeout=5)
 except urllib.error.HTTPError as error:r=error
 with r:
  raw=r.read().decode();return r.status,raw if host else json.loads(raw),r.headers

def rpc(method,params):
 status,data,_=request('/mcp',{'jsonrpc':'2.0','id':1,'method':method,'params':params},{'Authorization':'Bearer '+state['api_key'],'Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25','Mcp-Method':method});assert status==200 and 'error' not in data;return data['result']
def tool(name,args):return rpc('tools/call',{'name':name,'arguments':args})
if mode=='plan':
 status,_,headers=request('/api/v1/auth/login',{'username':'admin','password':state['password']});assert status==200;owner={'Cookie':headers['Set-Cookie'].split(';')[0],'X-Senix-CSRF':'1'}
 _,credentials,_=request('/api/v1/credentials',headers=owner);issued=next(c for c in credentials if c['label']=='locale-agent');expected=['instance.read','diagnostics.read','change.read','change.plan','change.apply'];assert sorted(issued['policy']['actions'])==sorted(expected) and issued['policy']['all_resources'] and issued['policy']['instance_ids']==[];assert abs(issued['expires_at_ms']-time.time()*1000-24*3600000)<180000
 tools=rpc('tools/list',{})['tools'];schema=next(t['inputSchema'] for t in tools if t['name']=='plan_change');assert set(schema['required'])=={'candidate','expected_version'};assert not any('approve' in t['name'] and t['name']!='apply_approved_change' for t in tools)
 current=tool('get_current_config',{})['structuredContent'];assert current['version']==1;candidate=copy.deepcopy(current['config']);candidate['routes'][0]['host']='new.test';plan=tool('plan_change',{'candidate':candidate,'expected_version':1})['structuredContent'];assert plan['base_version']==1 and not plan['issues'];cid=plan['change_id'];denied=tool('apply_approved_change',{'change_id':cid});assert denied['structuredContent']['code']=='CHANGE_APPROVAL_REQUIRED'
 (folder/'flow.json').write_text(json.dumps({'change_id':cid,'candidate':candidate,'ui_issued_key_actions':expected,'global_scope':True,'expiry_hours':24,'unapproved_apply_rejected':True,'version':1},indent=2)+'\n');print('PASS UI-issued Key grants, scope and expiry; MCP read, typed plan and unapproved rejection')
elif mode=='apply':
 flow=json.loads((folder/'flow.json').read_text());cid=flow['change_id'];approved=tool('get_change',{'change_id':cid})['structuredContent'];assert approved['status']=='APPROVED';applied=tool('apply_approved_change',{'change_id':cid})['structuredContent'];assert applied['version']==2;assert tool('apply_approved_change',{'change_id':cid})['structuredContent']==applied;current=tool('get_current_config',{})['structuredContent'];assert current['version']==2 and current['config']==flow['candidate']
 checks={}
 for host,status,body in [('new.test',200,'locale-A'),('untouched.test',200,'locale-B'),('old.test',404,None)]:
  actual,raw,_=request('/',host=host);assert actual==status and (body is None or raw==body);checks[host]=actual
 flow.update(owner_approved_in_english_ui=True,mcp_applied_version=2,repeated_apply_idempotent=True,exact_candidate_preserved=True,proxy_statuses=checks);(folder/'flow.json').write_text(json.dumps(flow,indent=2)+'\n');print('PASS English Owner approval, exact MCP application, replay and real changed/unchanged/old-host requests')
elif mode=='restart':
 flow=json.loads((folder/'flow.json').read_text());current=tool('get_current_config',{})['structuredContent'];assert current['version']==2 and current['config']==flow['candidate'];assert request('/api/v1/auth/login',{'username':'admin','password':state['password']})[0]==200
 assert request('/',host='new.test')[:2]==(200,'locale-A');assert request('/',host='untouched.test')[:2]==(200,'locale-B');flow['restart_preserves_exact_config_key_owner_and_proxy']=True;flow['binary_sha256']=hashlib.sha256(Path(state['binary']).read_bytes()).hexdigest();(folder/'flow.json').write_text(json.dumps(flow,indent=2)+'\n');print('PASS server restart preserves exact Snapshot v2, original Owner/Key and proxy responses')
